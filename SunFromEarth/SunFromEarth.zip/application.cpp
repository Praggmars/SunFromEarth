#include "application.h"


void Application::ChangeLatitudeFromMouse(int x, int y)
{
	float latitude = 0.0f;
	if (m_earthView.GetLatitude(
		x - (m_resolution.x - m_earthView.Resolution().x),
		y - (m_resolution.y - m_earthView.Resolution().y),
		latitude))
	{
		m_dayCycleView.SetLatitude(latitude);
	}
}

void Application::ChangeTiltFromMouse(int x, int y)
{
	const float tilt = (mth::float2(static_cast<float>(x), static_cast<float>(-y)) - mth::float2(
		static_cast<float>(m_resolution.x) - static_cast<float>(m_earthView.Resolution().x) * 0.5f,
		static_cast<float>(m_earthView.Resolution().y) * 0.5f - static_cast<float>(m_resolution.y))).Angle();
	m_earthView.SetTilt(tilt);
	m_dayCycleView.SetTilt(tilt);
}

void Application::PaintEvent()
{
	m_graphics.BeginDraw();

	m_earthView.Update();
	m_earthView.Render(m_graphics);
	m_graphics.Context2D()->DrawBitmap(m_earthView.OutputImage(), 
		D2D1::RectF(
			static_cast<float>(m_resolution.x - m_earthView.Resolution().x),
			static_cast<float>(m_resolution.y - m_earthView.Resolution().y),
			static_cast<float>(m_resolution.x),
			static_cast<float>(m_resolution.y)));
	m_dayCycleView.Render(m_graphics);
	m_graphics.Context2D()->DrawBitmap(m_dayCycleView.OutputImage(),
		D2D1::RectF(
			static_cast<float>(m_resolution.x - m_dayCycleView.Resolution().x),
			0.0f,
			static_cast<float>(m_resolution.x),
			static_cast<float>(m_dayCycleView.Resolution().y)));

	m_graphics.EndDraw();
	//ValidateRect(m_mainWindow, nullptr);
}

void Application::Resize(int width, int height)
{
	m_resolution.x = width;
	m_resolution.y = height;
	m_graphics.Resize(width, height);
	const int earthMapSize = min(width, height * 3 / 4);
	m_earthView.Resize(m_graphics, earthMapSize, earthMapSize);
	const int dayCycleHeight = earthMapSize / 3;
	m_dayCycleView.Resize(m_graphics, earthMapSize, dayCycleHeight);
}

void Application::MouseLButtonDownEvent(int x, int y, WPARAM flags)
{
	ChangeLatitudeFromMouse(x, y);
}

void Application::MouseRButtonDownEvent(int x, int y, WPARAM flags)
{
	ChangeTiltFromMouse(x, y);
}

void Application::MouseMoveEvent(int x, int y, WPARAM flags)
{
	if (flags & MK_LBUTTON)
		ChangeLatitudeFromMouse(x, y);
	if (flags & MK_RBUTTON)
		ChangeTiltFromMouse(x, y);
}

Application::Application()
	: m_mainWindow{} {}

Application::~Application() 
{
}

void Application::Init(const wchar_t* title, int width, int height)
{
	WNDCLASSEXW wc{};
	wc.cbSize = sizeof(wc);
	wc.hInstance = GetModuleHandleW(nullptr);
	wc.lpszClassName = title;
	wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = DefWindowProcW;
	RegisterClassExW(&wc);
	RECT rect{ 0, 0, width, height };
	AdjustWindowRectEx(&rect, WS_OVERLAPPEDWINDOW, false, 0);
	m_resolution.x = rect.right - rect.left;
	m_resolution.y = rect.bottom - rect.top;
	m_mainWindow = CreateWindowExW(0, title, title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, m_resolution.x, m_resolution.y, nullptr, nullptr, nullptr, nullptr);
	SetWindowLongPtrW(m_mainWindow, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(this));
	SetWindowLongPtrW(m_mainWindow, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(static_cast<LRESULT(*)(HWND, UINT, WPARAM, LPARAM)>(
		[](HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)->LRESULT {
			return reinterpret_cast<Application*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA))->MessageHandler(msg, wparam, lparam);
	})));

	m_graphics.Init(m_mainWindow);
	const int earthMapSize = min(m_resolution.x, m_resolution.y * 3 / 4);
	m_earthView.Init(m_graphics, earthMapSize, earthMapSize);
	const int dayCycleHeight = earthMapSize / 3;
	m_dayCycleView.Init(m_graphics, earthMapSize, dayCycleHeight);

	ShowWindow(m_mainWindow, SW_SHOWDEFAULT);
	UpdateWindow(m_mainWindow);
}

void Application::Run()
{
	MSG message{};
	while (GetMessageW(&message, nullptr, 0, 0))
	{
		TranslateMessage(&message);
		DispatchMessageW(&message);
	}
}

LRESULT Application::MessageHandler(UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
	case WM_MOUSEMOVE:
		MouseMoveEvent(LOWORD(lparam), HIWORD(lparam), wparam);
		return 0;
	case WM_LBUTTONDOWN:
		MouseLButtonDownEvent(LOWORD(lparam), HIWORD(lparam), wparam);
		return 0;
	case WM_RBUTTONDOWN:
		MouseRButtonDownEvent(LOWORD(lparam), HIWORD(lparam), wparam);
		return 0;
	case WM_PAINT:
		PaintEvent();
		return 0;
	case WM_SIZE:
		Resize(LOWORD(lparam), HIWORD(lparam));
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProcW(m_mainWindow, msg, wparam, lparam);
}