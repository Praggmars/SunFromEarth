#include "daycycleview.h"

void DayCycleView::ResizeCB()
{
	m_shaderData.resolution.x = static_cast<float>(m_resolution.x);
	m_shaderData.resolution.y = static_cast<float>(m_resolution.y);
}

void DayCycleView::Init(const Graphics& graphics, int width, int height)
{
	m_shader = graphics.CreateComputeShader(L"data/daycycleshader.cso");
	CreateImageResources(graphics, width, height);
	m_shaderParamBuffer = graphics.CreateConstBuffer(sizeof(m_shaderData));

	m_shaderData.dayColor = mth::float4(0.6902f, 0.8549f, 0.9098f, 1.0f);
	m_shaderData.civilTwilightColor = mth::float4(0.5882f, 0.7333f, 0.7882f, 1.0f);
	m_shaderData.nauticalTwilightColor = mth::float4(0.4353, 0.5608f, 0.6039f, 1.0f);
	m_shaderData.astronomicalTwilightColor = mth::float4(0.3451f, 0.4157f, 0.4392f, 1.0f);
	m_shaderData.nightColor = mth::float4(0.1843f, 0.2706f, 0.3020f, 1.0f);
	m_shaderData.latitude = 45.0f / 180.0f * mth::pi;
	m_shaderData.tilt = -23.5f / 180.0f * mth::pi;
}

void DayCycleView::Render(const Graphics& graphics) const
{
	ID3D11Buffer* cBuffer = m_shaderParamBuffer.Get();
	graphics.UpdateConstBuffer(cBuffer, &m_shaderData, sizeof(m_shaderData));
	graphics.Context3D()->CSSetConstantBuffers(0, 1, &cBuffer);
	LaunchShader(graphics);
}

void DayCycleView::SetTilt(float tilt)
{
	m_shaderData.tilt = tilt;
}

void DayCycleView::SetLatitude(float latitude)
{
	m_shaderData.latitude = latitude;
}
