#pragma once

#include "shaderviewbase.h"
#include "math/position.hpp"

class DayCycleView : public ShaderViewBase
{
public:
	struct ShaderData
	{
		mth::float4 dayColor;
		mth::float4 civilTwilightColor;
		mth::float4 nauticalTwilightColor;
		mth::float4 astronomicalTwilightColor;
		mth::float4 nightColor;
		mth::float2 resolution;
		float latitude;
		float tilt;

		ShaderData() = default;
	};

private:
	ComPtr<ID3D11Buffer> m_shaderParamBuffer;

	ShaderData m_shaderData;

protected:
	virtual void ResizeCB() override;

public:
	virtual void Init(const Graphics& graphics, int width, int height) override;

	virtual void Render(const Graphics& graphics) const override;

	void SetTilt(float tilt);
	void SetLatitude(float latitude);
};
